<header>
    <div class="logo">
        <img src="../Images/Logo.png" alt="Logo">
    </div>
    <nav class="navbar">
        <ul>
            <li><a href="../PHP/onderwerp_fortnite.php">Fortnite</a></li>
            <li><a href="../PHP/onderwerp_bloonsTD.php">Bloons TD</a></li>
            <li><a href="../PHP/onderwerp_minecraft.php">Minecraft</a></li>
            <li><a href="../PHP/onderwerp_CodeTalen.php">Code talen</a></li>
        </ul>
    </nav>
</header>