<footer>

    <nav class="footerbar">
        <p>Email: 99077364@mydavinci.nl</p>
        <p>Jacco Bos | 30-5-2024 | Auteursrecht 2024</p>
    </nav>
</footer>