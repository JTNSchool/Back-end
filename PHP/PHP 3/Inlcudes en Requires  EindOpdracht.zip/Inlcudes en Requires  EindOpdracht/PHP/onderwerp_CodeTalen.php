
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="../CSS/header.css">
    <link rel="stylesheet" href="../CSS/body.css">
    <link rel="stylesheet" href="../CSS/footer.css">
    <title>Eindopdracht</title>
</head>

<body>
<?php require("../Includes/header.php") ?>


<h1>Code talen</h1>

<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed imperdiet eleifend risus, quis dignissim erat aliquet semper. Praesent a ornare sapien, pellentesque varius velit. Donec finibus ipsum ut aliquam luctus. Proin ac orci nunc. Donec in sodales sapien. Praesent eu aliquet orci. Integer tincidunt nulla massa, vitae imperdiet metus consectetur non. Sed lobortis ex ac quam ultrices, non vulputate ex sollicitudin. Phasellus et nunc ligula. Praesent sit amet nisl sapien. Curabitur at sapien varius, venenatis leo sit amet, lacinia dui. Nam sed venenatis tellus.

    Curabitur fermentum nibh ac purus lobortis suscipit. Aliquam erat volutpat. Proin blandit pulvinar auctor. Nam accumsan quis risus ut maximus. Sed suscipit magna ac lacus rutrum suscipit. Morbi ultricies ligula mi, ut tempus nibh egestas ultrices. Donec elementum, nibh in ullamcorper lacinia, ligula tortor dignissim ante, eu pulvinar nisi ex vitae purus. Morbi faucibus, dolor a ultricies aliquam, nulla tortor pellentesque turpis, at aliquet est libero nec quam. Integer sit amet ullamcorper nunc, at vehicula est. Donec fringilla vehicula mi, sit amet dictum velit rhoncus non. Morbi sodales vel felis sit amet ultricies. Ut id orci ligula. Etiam porttitor, orci id lacinia sagittis, dui lorem suscipit ligula, in volutpat felis tortor vel sem.

    Nam dapibus eros eu est efficitur vestibulum. Pellentesque lorem orci, tempus commodo lorem vel, tincidunt facilisis lacus. Proin iaculis magna et arcu tristique, eget interdum tortor molestie. Vestibulum ac metus vel elit accumsan tempus nec vitae turpis. Ut malesuada eleifend tellus id tristique. Pellentesque sagittis augue nibh, at bibendum ipsum tincidunt et. Quisque in tellus eget eros pellentesque interdum vitae ac velit. Praesent posuere hendrerit accumsan.

    Nam fermentum egestas nunc et malesuada. Donec malesuada orci non tellus laoreet, quis lobortis tortor feugiat. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed lacinia libero vel libero sodales bibendum. Cras ullamcorper, dolor non imperdiet tincidunt, odio augue feugiat odio, vel vestibulum felis nisl eu ante. Curabitur venenatis lectus nec semper laoreet. Praesent at lacinia nisi. Curabitur eget lobortis est, vitae faucibus elit. Donec et enim at dui tempus ultrices. Proin facilisis ante sed lacus cursus, ac efficitur sem lobortis. Fusce fermentum tortor sem, id ullamcorper lectus consectetur in. Curabitur rutrum justo ut nibh elementum, a finibus enim consequat.

    Aliquam interdum non lectus quis commodo. Nulla id lacus eget orci dictum vestibulum nec sit amet metus. Maecenas vitae nisi porta, rutrum mi id, mollis lectus. Nam accumsan vel tellus non laoreet. Phasellus pharetra ipsum vel est ultricies luctus. Mauris placerat pellentesque quam sed blandit. In euismod consectetur ligula nec pharetra. Nunc tincidunt ornare eleifend. Aenean sed posuere nisl, ut ultricies nisi. In sit amet urna sed risus tristique vulputate.</p>



<?php require("../Includes/footer.php") ?>
</body>

</html>