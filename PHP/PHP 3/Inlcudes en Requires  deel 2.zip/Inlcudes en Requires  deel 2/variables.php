<?php
    $Voornaam = "Henk";
    $Achternaam = "Gans";
    $Fruitmand = ["Appel", "Peer", "Banaan"];